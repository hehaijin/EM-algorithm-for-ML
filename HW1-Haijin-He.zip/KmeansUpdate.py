import numpy as np
from Kmeans import Kmeans


def KmeansUpdate(D, ri):
	

