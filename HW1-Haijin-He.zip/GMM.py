
import scipy.stats
import numpy
from gData import gData
import matplotlib.pyplot as plt

def GMM(data,mus,coMs,pis):
	D=data.shape[1]
	N=data.shape[0]
	K=len(mus)
	
	#initiate data structure
	rmus=numpy.zeros((K,D))
	rcoMs=numpy.zeros((K,D,D))
	rpis=numpy.zeros(K)
	rik=numpy.zeros((N,K))
	rk=numpy.zeros(K)
	
	#updating rik matrix
	for i in range(N):
		for j in range(K):
			mu=mus[j]
			co=coMs[j]
			pi=pis[j]
			rik[i][j]= pis[j]* scipy.stats.multivariate_normal.pdf(data[i],mu,co)
		sum=0
		for j in range(K):
			sum=sum+rik[i][j]
		
		for j in range(K):
			rik[i][j]=rik[i][j]/sum
	return rik
	


def updatePi(rik):
	N=rik.shape[0]
	K=rik.shape[1]
	rpis=np.zeros(K)
	for i in range(K):
		for j in range(N):
			rpis[i]=rpis[i]+rik[j][i]
		rpis[i]=rpis[i]/N
	return rpis
	

def updateMuVa(data,rik):
	N=rik.shape[0]
	K=rik.shape[1]
	
		
	#update mus 
	for i in range(K):
		for j in range(N):
			rmus[i]=rmus[i]+rik[j][i]*data[j]
			rk[i]=rk[i]+rik[j][i]
		rmus[i]=rmus[i]/rk[i]
	
	#update covariance
	#use outer rather than dot
	for i in range(K):
		for j in range(N):
			rcoMs[i]=rcoMs[i] + rik[j][i]*numpy.outer(data[j],data[j])
		rcoMs[i]=rcoMs[i]/rk[i]
		rcoMs[i]=rcoMs[i]-numpy.outer(rmus[i],rmus[i])
	return (rmus,rcoMs)
	






def GMMiterate(data, mus, coMs, pis):
	#get data dimention
	D=data.shape[1]
	N=data.shape[0]
	K=len(mus)
	
	#initiate data structure
	rmus=numpy.zeros((K,D))
	rcoMs=numpy.zeros((K,D,D))
	rpis=numpy.zeros(K)
	rik=numpy.zeros((N,K))
	rk=numpy.zeros(K)
	
	#updating rik matrix
	for i in range(N):
		for j in range(K):
			mu=mus[j]
			co=coMs[j]
			pi=pis[j]
			rik[i][j]= pis[j]* scipy.stats.multivariate_normal.pdf(data[i],mu,co)
		sum=0
		for j in range(K):
			sum=sum+rik[i][j]
		
		for j in range(K):
			rik[i][j]=rik[i][j]/sum
	
	
	
	#update mus 
	for i in range(K):
		for j in range(N):
			rmus[i]=rmus[i]+rik[j][i]*data[j]
			rk[i]=rk[i]+rik[j][i]
		rmus[i]=rmus[i]/rk[i]
	
	#update covariance
	#use outer rather than dot
	for i in range(K):
		for j in range(N):
			rcoMs[i]=rcoMs[i] + rik[j][i]*numpy.outer(data[j],data[j])
		rcoMs[i]=rcoMs[i]/rk[i]
		rcoMs[i]=rcoMs[i]-numpy.outer(rmus[i],rmus[i])
	
	
    #update pis

	for i in range(K):
		for j in range(N):
			rpis[i]=rpis[i]+rik[j][i]
		rpis[i]=rpis[i]/N
		
	#calculate log likilihood
	loglik=0
	for i in range(N):
		for j in range(K):
			loglik=loglik+rik[i][j]* numpy.log(scipy.stats.multivariate_normal.pdf(data[i],rmus[j],rcoMs[j]))+rik[i][j]*numpy.log(rpis[j]) 
		   

	
	return (rmus,rcoMs,rpis,loglik,rik)




def GMMrun(data, K):
	N=data.shape[0]
	D=data.shape[1]
	
	#parameter initialization
	mus=numpy.ones((K,D))/10
	for i in range(K):
		mus[i]=mus[i]+numpy.random.rand(D)
	
	#covariance matrix must not be singular
	coMs=numpy.zeros((K,D,D))
	for i in range(K):
		coMs[i]=numpy.identity(D)

	pis=numpy.ones(K)/K
	
	#iterate
	loglik=1;
	dlog=1;
	
	while dlog > 0.001:
		(rmus,rcoMs,rpis,logliks,rik)=GMMiterate(data,mus, coMs, pis)
		dlog=logliks-logliks
		loglik=logliks
	
	return (rik,rmus,rcoMs)
	
	
	 
	
	
 
