
import numpy as np
from Mahalanobis  import Mahalanobis
import math


def Kmeans(data,mus,coMs):
	N=data.shape[0]  #number of samples
	K=mus.shape[0]  # number of classes
	ri=np.zeros(N) #similar to GMM, but here we will use hard EM
	result=Mahalanobis(data,mus,coMs)
	for i in range(N):
		maxi=result[i][0];
		zi=0
		for j in range(K):
			if result[i][j] > maxi:
				maxi=result[i][j]
				zi=j
		ri[i]=zi
	
	return ri
	
	
	   
def KmeansUpdate(data,ri,K): 
	N=data.shape[0]
	D=data.shape[1]
	rmus=np.zeros((K,D))
	rcoMs=np.zeros((K,D,D))
    #create EM style rik so to reuse code
	rik=np.zeros((N,K))
	rk=np.zeros(K)
    
	for i in range(N):
		t=math.floor(ri[i])
		rik[i][t]=1
			
    #update mus 
	for i in range(K):
		for j in range(N):
			rmus[i]=rmus[i]+rik[j][i]*data[j]
			rk[i]=rk[i]+rik[j][i]
		rmus[i]=rmus[i]/rk[i]
	
	#update covariance
	#use outer rather than dot
	for i in range(K):
		for j in range(N):
			rcoMs[i]=rcoMs[i] + rik[j][i]*np.outer(data[j],data[j])
		rcoMs[i]=rcoMs[i]/rk[i]
		rcoMs[i]=rcoMs[i]-np.outer(rmus[i],rmus[i])
	return (rmus,rcoMs)
    
"""
    count=np.zeros(K)
    
    for i in range(N):
		count[ri[i]]=count[ri[i]]+1 #calculate the count for each class
		mus[ri[i]]=mus[ri[i]]+data[i]
	#get average
	for i in range(K):
		mus[i]=mus[i]/count[i]

""" 

	
	
def meandiff(mus,rmus):
	K=np.shape(mus)[0]
	D=np.shape(mus)[1]
	delta=rmus-mus
	result=0
	for i in range(K):
		result=result+ np.linalg.norm(delta[i])
	result=result/K
	return result
	
	

	
	
def Kmeansrun(data,K):
	N=np.shape(data)[0]
	D=np.shape(data)[1]
	
	#parameter initialization
	mus=np.ones((K,D))/10
	for i in range(K):
		mus[i]=mus[i]+np.random.rand(D)
	
	#covariance matrix must not be singular
	coMs=np.zeros((K,D,D))
	for i in range(K):
		coMs[i]=np.identity(D)

	pis=np.ones(K)/K
	
	ri=Kmeans(data,mus,coMs)
	(rmus,rcoMs)=KmeansUpdate(data,ri,K)
	while meandiff(mus,rmus) > 0.001 :
		mus=rmus
		coMs=rcoMs
		ri=Kmeans(data,mus,coMs)
		(rmus,rcoMs)=Kmeansupdate(data,ri,K)
	return (ri,rmus,rcoMs)

	
